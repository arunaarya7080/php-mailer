<?php
// Include the PHPMailer Autoload file
require 'smtp_mailer/PHPMailer.php';
require 'smtp_mailer/SMTP.php';
require 'smtp_mailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Replace these variables with your own values
 $toEmail = 'arun@deltaweb.in';
//$toEmail = 'arunoffice7080@gmail.com';
$subject = 'Test Email';
$message = 'This is a test email sent using PHPMailer.';
$fromEmail = 'test@repaircenter.qa';
$smtpHost = 'smtp.hostinger.com';
$smtpUsername = 'test@repaircenter.qa';
$smtpPassword = 'Admin@#$%1234';
$smtpPort = 465; // Update with your SMTP server port

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->SMTPDebug = 2; // Set to 0 for no debugging information
    $mail->isSMTP();
    $mail->Host = $smtpHost;
    $mail->SMTPAuth = true;
    $mail->Username = $smtpUsername;
    $mail->Password = $smtpPassword;
    $mail->SMTPSecure = 'ssl'; // Use 'tls' for port 587
    $mail->Port = $smtpPort;

    // Recipients
    $mail->setFrom($fromEmail);
    $mail->addAddress($toEmail);

    // Content
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $message;

    // Send email
    $mail->send();
    echo 'Email sent successfully.';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>
